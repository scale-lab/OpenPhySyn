---
name: Feature request
about: Suggest an idea for this project

---

**Please describe your feature request.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

